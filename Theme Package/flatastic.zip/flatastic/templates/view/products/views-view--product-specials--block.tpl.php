<figure class="widget shadow r_corners wrapper m_bottom_30">
    <?php print $header;?>
    <div class="widget_content">
        <div class="specials_carousel">
            <!--carousel item-->
            <?php print $rows;?>
        </div>
    </div>
</figure>
