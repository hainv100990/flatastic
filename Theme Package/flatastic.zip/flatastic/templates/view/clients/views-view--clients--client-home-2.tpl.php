<?php print $header;?>
<div class="product_brands with_sidebar m_sm_bottom_35">

  <?php print $rows;?>
</div>
