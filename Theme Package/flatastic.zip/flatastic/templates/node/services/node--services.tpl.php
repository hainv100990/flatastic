
<div class="bg_light_color_3 r_corners shadow manufacturers">
    <?php if(isset($content['body'])): print render($content['body']); endif;?>
</div>

