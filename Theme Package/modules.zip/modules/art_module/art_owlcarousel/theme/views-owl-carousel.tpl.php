<div id="<?php print $view_id; ?>" class="<?php print $wrapper_class; ?>">
	<?php foreach ($rows as $id => $row): ?>
		<?php print $row; ?>
	<?php endforeach; ?>
</div>